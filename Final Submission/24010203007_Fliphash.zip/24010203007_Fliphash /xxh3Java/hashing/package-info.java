/** Hash algorithms */
package  fliphash.xxh3Java.hashing;
