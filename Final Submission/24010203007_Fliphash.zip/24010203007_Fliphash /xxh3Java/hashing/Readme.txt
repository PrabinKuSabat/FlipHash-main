This repo contains a C implementaion of the constant time hashing algorithm FlipHash.
Also rightnow I'm developing the java implementation of the FlipHash algorithm.
Wait for more details on the java implementation.

Thanks!